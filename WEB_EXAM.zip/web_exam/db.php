<?php

$con = mysqli_connect("localhost","root","","web_exam") or die(mysqli_error($con));

 ?>
